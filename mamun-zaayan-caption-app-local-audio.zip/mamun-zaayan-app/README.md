# Mamun Zaayan Caption App

একটি স্টাইলিশ, বাংলা-ভিত্তিক caption PWA — আপনার দেওয়া প্রোফাইল ছবি, Instagram/YouTube লিংক, ক্যাটাগরি ফিল্টার, সার্চ, কপি ও শেয়ার বাটন, এবং অ্যাডমিন ড্যাশবোর্ডসহ।

## চালানো

লোকাল প্রিভিউর জন্য প্রজেক্ট ফোল্ডারে চালান:

```bash
python3 -m http.server 4173
```

তারপর `http://localhost:4173` খুলুন। `file://` দিয়ে খুললেও মূল ইন্টারফেস চলবে; PWA offline cache-এর জন্য HTTP/HTTPS ব্যবহার করুন।

## অ্যাডমিন

উপরের **অ্যাডমিন প্যানেল** বাটনে ক্লিক করে ডেমো PIN `1234` দিয়ে ঢুকুন। এখান থেকে ক্যাপশন, মেনু এবং shareable admin invite link তৈরি করা যায়। ডেটা এই ব্রাউজারের localStorage-এ থাকে।

## ফ্রি হোস্টিং

এই ফোল্ডারটি GitHub Pages, Netlify বা Cloudflare Pages-এর মতো যেকোনো free static host-এ আপলোড করা যাবে। `index.html`, `manifest.webmanifest`, `sw.js`, এবং `assets/profile.jpg` একই structure-এ রাখবেন।

## গুরুত্বপূর্ণ সীমা

এটি backend ছাড়া standalone সংস্করণ। তাই নতুন ক্যাপশন/মেনু/analytics বর্তমানে **যে ব্রাউজারে অ্যাডমিন কাজটি করা হয়, সেই ব্রাউজারেই** সংরক্ষিত হয়। সব visitor-এর জন্য একসাথে server-synced content ও global analytics পেতে পরে একটি database/backend (যেমন Supabase/Firebase বা WebDev full-stack project) যোগ করতে হবে।
